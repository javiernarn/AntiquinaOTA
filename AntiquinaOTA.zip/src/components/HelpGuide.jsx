import React, { useEffect, useRef, useState } from "react";
import {
  HelpCircle,
  X,
  Users,
  Plus,
  FileDown,
  Bell,
  Sun,
  Sunset,
  Moon,
  ShieldCheck,
  ChevronDown,
} from "lucide-react";

// A single, self-contained "how this works" reference for the OJT trainee.
// Content mirrors the actual app logic 1:1 (host client schedules,
// shift-coverage rules, real-time progress, PDF export gating) so it never
// tells the trainee something the code doesn't actually do. Shared by both
// the always-available Help (?) button and the one-time onboarding
// walkthrough shown on first sign-in.
function GuideContent() {
  return (
    <>
      <p className="help-intro">
        This app is your digital Daily Time Record (DTR). It tracks your OJT hours
        against your required total, in real time, and can generate a signable PDF
        report for your coordinator. Here's exactly how each part works.
      </p>

      <section className="help-section">
        <h3><Users size={14} /> 1. Set up your profile &amp; host clients</h3>
        <ul>
          <li><strong>Trainee name</strong> and <strong>Required hours</strong> (e.g. 486h) appear on the printed report — fill these in first.</li>
          <li><strong>Host clients</strong> are the company/office you're deployed to. Add one with its <em>type</em>:
            <ul>
              <li><strong>Public</strong> — Mon–Thu, 8:00 AM–5:00 PM (default)</li>
              <li><strong>Private</strong> — Mon–Fri, 7:00 AM–6:00 PM (default)</li>
              <li><strong>Custom</strong> — set your own days and time in/out</li>
            </ul>
          </li>
          <li>You can edit a host client's schedule any time. A host client that's already used on a saved entry <strong>can't be deleted</strong> until you edit/remove those entries first — this protects your logged hours from being orphaned.</li>
        </ul>
      </section>

      <section className="help-section">
        <h3><Plus size={14} /> 2. Adding a day</h3>
        <ul>
          <li>Use <strong>Add day</strong> at the bottom of the Logbook tab to log a shift — for today or any past date.</li>
          <li>Choose the <strong>shift coverage</strong> for that entry:
            <span className="help-inline-icons">
              <Sun size={12} /> Morning only, <Sunset size={12} /> Afternoon only, <Moon size={12} /> Evening only,
              Afternoon → Evening, or Whole day.
            </span>
          </li>
          <li>Available options adjust automatically — e.g. you can't pick "Morning" for today's date once it's already past 12:00 PM, and the options narrow to match whatever hours your selected host client actually works.</li>
          <li>A <strong>host client is required</strong> on every entry, and the time ranges can't overlap another entry already logged for that same date.</li>
          <li>Use the <strong>pencil icon</strong> on any row to correct it (e.g. an early out), or the <strong>trash icon</strong> to delete it (with a confirmation prompt).</li>
        </ul>
      </section>

      <section className="help-section">
        <h3><ShieldCheck size={14} /> 3. Real-time progress &amp; completion</h3>
        <ul>
          <li>The hero ring shows total hours logged vs. your required hours, and updates live as scheduled shift time actually elapses.</li>
          <li>An entry added for a time that hasn't happened yet (e.g. adding today's 8–5 shift at 7:59 AM) contributes <strong>0 hours</strong> until that time actually arrives, then ticks up in real time — it never lets you claim hours you haven't worked yet.</li>
          <li>Each entry gets a badge: <strong>Scheduled</strong> (hasn't started), <strong>In progress</strong> (currently running), <strong>Complete</strong> (met the standard hours for its coverage), or a <strong>−Xh</strong> short badge if it fell short.</li>
        </ul>
      </section>

      <section className="help-section">
        <h3><FileDown size={14} /> 4. Reports &amp; exporting your PDF</h3>
        <ul>
          <li>The <strong>Reports</strong> tab breaks your hours down by Morning/Afternoon/Evening, by host client, by shift type, and shows a day-by-day detailed log.</li>
          <li><strong>Export PDF Report</strong> generates an official, signable Duty Time Record — choose Daily, Weekly summary, or Monthly summary before exporting.</li>
          <li>Export is <strong>locked while a logged shift is still running</strong> (its scheduled end time hasn't passed yet) — a report only reflects hours that have actually finished.</li>
          <li>The PDF includes trainee info, a summary of hours/remaining/progress/overtime, the full log table, an hourly breakdown, and signature lines for you and your supervisor/coordinator.</li>
        </ul>
      </section>

      <section className="help-section">
        <h3><Bell size={14} /> 5. Notifications</h3>
        <ul>
          <li>The bell icon logs every milestone (25%/50%/75%/100% of your required hours), a heads-up before your shift's scheduled start time, and warnings (e.g. browser storage issues).</li>
          <li>Tap <strong>"Turn on desktop alerts"</strong> in the panel to also get OS-level notifications even when this tab isn't focused.</li>
        </ul>
      </section>

      <section className="help-section">
        <h3><ShieldCheck size={14} /> 6. Your data &amp; privacy</h3>
        <ul>
          <li>Your logbook is tied to your signed-in Google account and stored securely (encrypted) in <strong>this browser only</strong> — it is not uploaded to a server.</li>
          <li>Using a different device or browser starts a fresh, empty logbook for that device. Export a PDF regularly so you always have a backup copy of your official record.</li>
        </ul>
      </section>
    </>
  );
}

// Always-available reference, opened from the (?) button beside the
// notification bell. Freely dismissible — unlike the onboarding version
// below, this one isn't gating anything, so it closes on backdrop click,
// the X button, or Escape.
export function HelpButton() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        className="help-btn"
        onClick={() => setOpen(true)}
        aria-label="How to use the Duty Log"
        title="How to use the Duty Log"
      >
        <HelpCircle size={18} />
      </button>

      {open && (
        <div className="help-overlay" role="presentation" onClick={() => setOpen(false)}>
          <div
            className="help-card"
            role="dialog"
            aria-modal="true"
            aria-labelledby="help-title"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="help-card-head">
              <h2 id="help-title">How the OJT Duty Log works</h2>
              <button className="icon-btn" onClick={() => setOpen(false)} aria-label="Close">
                <X size={16} />
              </button>
            </div>

            <div className="help-card-body">
              <GuideContent />
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// One-time walkthrough shown automatically the first time a fresh/new
// account signs in (see LogbookPage's onboarding-seen check). Deliberately
// NOT dismissible via backdrop click, Escape, or an X button — the trainee
// has to actually scroll the guide to its end before Done/Skip unlock, so
// a first-time user can't accidentally miss how host clients, adding a
// day, and PDF export work before they start using the app for real.
export function OnboardingGuide({ open, onDone }) {
  const [reachedBottom, setReachedBottom] = useState(false);
  const bodyRef = useRef(null);

  // Re-check whenever the modal opens (covers the case where the content
  // is already short enough to not need scrolling at all on a tall screen).
  useEffect(() => {
    if (!open) {
      setReachedBottom(false);
      return;
    }
    const el = bodyRef.current;
    if (!el) return;
    if (el.scrollHeight - el.clientHeight <= 4) setReachedBottom(true);
  }, [open]);

  function handleScroll(e) {
    const el = e.currentTarget;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight <= 4;
    if (atBottom) setReachedBottom(true);
  }

  if (!open) return null;

  return (
    <div className="help-overlay onboarding-overlay" role="presentation">
      <div
        className="help-card onboarding-card"
        role="dialog"
        aria-modal="true"
        aria-labelledby="onboarding-title"
      >
        <div className="help-card-head">
          <h2 id="onboarding-title">Welcome! Here's how the OJT Duty Log works</h2>
        </div>

        <div className="help-card-body" ref={bodyRef} onScroll={handleScroll}>
          <GuideContent />
          <p className="onboarding-end-marker">
            That's everything — you're ready to set up your host client and start logging your hours.
          </p>
        </div>

        <div className="onboarding-footer">
          {!reachedBottom && (
            <span className="onboarding-scroll-hint">
              <ChevronDown size={13} /> Scroll down to read the full guide
            </span>
          )}
          <div className="onboarding-actions">
            <button
              type="button"
              className="onboarding-skip-btn"
              disabled={!reachedBottom}
              onClick={onDone}
            >
              Skip
            </button>
            <button
              type="button"
              className="onboarding-done-btn"
              disabled={!reachedBottom}
              onClick={onDone}
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HelpButton;
